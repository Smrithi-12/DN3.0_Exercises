package com.InventoryManagementSystem;

import java.util.HashMap;

public class Inventory {
    private HashMap<String , Products> pros;
    public Inventory() {
        pros = new HashMap<>();
    }
    public void addProduct(Products product) {
        pros.put(product.getId(), product);
    }
    public void updateProduct(Products product) {
        if (pros.containsKey(product.getId())) {
            pros.put(product.getId(), product);
        } else {
            System.out.println("Product not found.");
        }
    }
    public void deleteProduct(String productId) {
        pros.remove(productId);
    }
    public Products getProduct(String productId) {
        return pros.get(productId);
    }
}
