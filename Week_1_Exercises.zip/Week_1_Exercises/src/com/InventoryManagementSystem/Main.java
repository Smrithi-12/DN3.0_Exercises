package com.InventoryManagementSystem;

public class Main {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        // Adding products by creating the new objects
        Products product1 = new Products("1", "Laptop", 2, 99);
        Products product2 = new Products("2", "Mobile", 3, 499);
        inventory.addProduct(product1);
        inventory.addProduct(product2);

        // Updating the product using setQuantity and updateProduct methods
        product1.setQuantity(15);
        inventory.updateProduct(product1);

        // Getting/retrieving the product using getProduct method which is in the inventory class
        Products productGot = inventory.getProduct("1");  // --> Hard coded to test whether this implementation works correctly
        if (productGot != null) {
            System.out.println("Product ID: " + productGot.getId());
            System.out.println("Product Name: " + productGot.getName());
            System.out.println("Quantity: " + productGot.getQuantity());
            System.out.println("Price: " + productGot.getPrice());
        } else {
            System.out.println("Product not found.");
        }

        // Deleting the product using the deleteProduct method which is in the inventory class
        inventory.deleteProduct("102");
    }
}
