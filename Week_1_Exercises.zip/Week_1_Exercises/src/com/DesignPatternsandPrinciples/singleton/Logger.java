package com.DesignPatternsandPrinciples.singleton;
class Singleton{
    private static Singleton instance =  new Singleton();
    private Singleton(){ // creating the private constructor to prevent the creation of new object
    }
    public static Singleton getInstance(){
        return instance;
    }
}
public class Logger {
    public static void main(String[] args){
        // Singleton s1 = new Singleton(); --> This is not possible because it is a singleton class
        Singleton s1 = Singleton.getInstance();
        Singleton s2 = Singleton.getInstance();
        System.out.println(s1==s2); // --> Testing the Singleton Implementation
        System.out.println(s1.hashCode()); // --> Testing the Singleton Implementation
        System.out.println(s2.hashCode()); // --> Testing the Singleton Implementation
    }
}
