package com.DesignPatternsandPrinciples.singleton;

public class Logger2 {
    public static void main(String[] args){
        // Runtime r1 = new Runtime(); --> We cannot create a new object

        Runtime r1 = Runtime.getRuntime();
        Runtime r2 = Runtime.getRuntime();
        System.out.println(r1 == r2);
        System.out.println(r1.hashCode());
        System.out.println(r2.hashCode());
    }
}
