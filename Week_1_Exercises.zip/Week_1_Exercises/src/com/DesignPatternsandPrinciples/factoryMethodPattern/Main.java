package com.DesignPatternsandPrinciples.factoryMethodPattern;
/* Explanation :
        Factory method act as a option provider where if we select pdf --> generates pdf
                                                                   excel --> generated excel
                                                                   word --> generated word
        Real-time example acts where --> gives the required one when asked.
*/
public class Main {
    public static void main(String[] args){
        Document pdf = DocumentFactory.createDocument("Pdf");
        pdf.create();
        Document excel = DocumentFactory.createDocument("Excel");
        excel.create();
        Document word = DocumentFactory.createDocument("Word");
        word.create();
    }
}
