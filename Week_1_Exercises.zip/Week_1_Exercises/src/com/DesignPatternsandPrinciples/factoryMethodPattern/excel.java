package com.DesignPatternsandPrinciples.factoryMethodPattern;

public class excel implements Document{ // creating new class which implements the Document interface
    public void create(){
        System.out.println("Creating excel Document");
    }
}
