package com.DesignPatternsandPrinciples.factoryMethodPattern;

public interface Document {
    void create();
}
