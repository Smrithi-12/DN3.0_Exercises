package com.DesignPatternsandPrinciples.factoryMethodPattern;

public class DocumentFactory {
    public static Document createDocument(String docType){
        if(docType.equalsIgnoreCase("pdf")){
            return new pdf();
        }
        else if(docType.equalsIgnoreCase("excel")){
            return new excel();
        }
        else if(docType.equalsIgnoreCase("word")){
            return new word();
        }
        else{
            throw new IllegalArgumentException("Illegal Document Type");
        }
    }
}
