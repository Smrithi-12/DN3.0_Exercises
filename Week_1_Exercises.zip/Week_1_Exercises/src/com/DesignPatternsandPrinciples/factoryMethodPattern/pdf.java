package com.DesignPatternsandPrinciples.factoryMethodPattern;
public class pdf implements Document{ // creating new class which implements the Document interface
    public void create(){
        System.out.println("Creating PDF Document");
    }
}
