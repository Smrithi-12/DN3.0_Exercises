package com.DesignPatternsandPrinciples.DecoraterPattern;

public class EmailNotifier extends Notifier {
    @Override
    public String getSend() {
        return "Sending Email Notification...";
    }
}
