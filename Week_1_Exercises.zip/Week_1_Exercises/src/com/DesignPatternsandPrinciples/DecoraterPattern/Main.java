package com.DesignPatternsandPrinciples.DecoraterPattern;

public class Main {
    public static void main(String[] args){
        Notifier notifier = new EmailNotifier();
        System.out.println(notifier.getSend());

        notifier = new SMSNotifierDecorater(notifier);
        System.out.println(notifier.getSend());

        notifier = new SlackNotifierDecorater(notifier);
        System.out.println(notifier.getSend());
    }
}
