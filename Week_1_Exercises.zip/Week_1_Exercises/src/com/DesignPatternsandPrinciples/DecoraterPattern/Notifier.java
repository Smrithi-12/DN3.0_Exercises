package com.DesignPatternsandPrinciples.DecoraterPattern;

public abstract class Notifier {
    public abstract  String getSend();
}
