package com.DesignPatternsandPrinciples.DecoraterPattern;
/*
    This decorater class helps us to decorate our code based on our needs.
    --> This is a abstract class which extends Notifier
 */
public abstract class NotifierDecorator extends Notifier{

}
