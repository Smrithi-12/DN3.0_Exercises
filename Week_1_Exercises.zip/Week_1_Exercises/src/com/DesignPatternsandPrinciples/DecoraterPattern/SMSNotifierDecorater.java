package com.DesignPatternsandPrinciples.DecoraterPattern;

public class SMSNotifierDecorater extends NotifierDecorator{
    private Notifier notify;
    public SMSNotifierDecorater(Notifier notify){
        this.notify = notify;
    }
    public String getSend(){
        return notify.getSend() + "Sending SMS Notification...";

    }


}
