package com.DesignPatternsandPrinciples.DecoraterPattern;

public class SlackNotifierDecorater extends NotifierDecorator{
    private Notifier notify;
    public SlackNotifierDecorater(Notifier notify){
        this.notify = notify;
    }
    public String getSend(){
        return notify.getSend() + "Sending Slack Notification";

    }
}
