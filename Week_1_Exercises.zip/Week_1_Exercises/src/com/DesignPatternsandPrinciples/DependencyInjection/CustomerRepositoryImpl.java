package com.DesignPatternsandPrinciples.DependencyInjection;

public class CustomerRepositoryImpl implements CustomerRepository{
    public Customer findCustomerById(String id){
        return new Customer(id, "abc");
    }
}
