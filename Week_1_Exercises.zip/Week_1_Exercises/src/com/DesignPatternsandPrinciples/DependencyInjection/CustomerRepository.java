package com.DesignPatternsandPrinciples.DependencyInjection;

public interface CustomerRepository {
    Customer findCustomerById(String id);
}
