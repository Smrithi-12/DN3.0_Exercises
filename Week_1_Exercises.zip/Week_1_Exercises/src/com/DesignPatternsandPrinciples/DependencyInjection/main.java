package com.DesignPatternsandPrinciples.DependencyInjection;

public class main {
    public static void main(String[] args) {
        CustomerRepository customerRepos = new CustomerRepositoryImpl();

        // Injecting the repository into the service
        CustomerService customer = new CustomerService(customerRepos);
        Customer customers = customer.getCustomerById("123");
        System.out.println("ID: " + customers.getId());
        System.out.println("Name: " + customers.getName());
    }
}
