package com.DesignPatternsandPrinciples.BuilderMethodPattern;

public class Main {

    public static void main(String[] args) {
        Computer Dell = new Computer.ComputerBuilder("Dual-Core", 4).setStorage(5).build();
        Computer HP = new Computer.ComputerBuilder("Single-Core", 6).setStorage(10).build();

        System.out.println(Dell.getCPU());
        System.out.println(Dell.getRAM());
        System.out.println(Dell.getStorage());

        System.out.println(HP.getStorage());
        System.out.println(HP.getRAM());
        System.out.println(HP.getCPU());
    }
}