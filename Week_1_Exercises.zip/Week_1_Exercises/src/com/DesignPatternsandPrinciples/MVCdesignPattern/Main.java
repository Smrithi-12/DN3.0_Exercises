package com.DesignPatternsandPrinciples.MVCdesignPattern;

public class Main {
    public static void main(String[] args) {
        Student student = new Student("abc", "123", "A");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(student, view);
        controller.updatedetails();
        System.out.println("---------------");
        controller.setStudentName("bca");
        controller.setStudentGrade("B");
        controller.updatedetails();
    }
}
