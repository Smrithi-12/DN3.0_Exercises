package com.DesignPatternsandPrinciples.MVCdesignPattern;

public class StudentView {
    public void displayStudentDetails(String name, String Id, String Grade) {
        System.out.println("Name: " + name);
        System.out.println("ID: " + Id);
        System.out.println("Grade: " + Grade);
    }
}
