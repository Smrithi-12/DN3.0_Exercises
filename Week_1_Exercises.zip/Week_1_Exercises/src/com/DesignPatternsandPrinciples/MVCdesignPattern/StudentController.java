package com.DesignPatternsandPrinciples.MVCdesignPattern;

public class StudentController {
    private Student sample;
    private StudentView view;
    public StudentController(Student sample,StudentView view) {
        this.sample = sample;
        this.view = view;
    }
    public String getStudentName() {
        return sample.getName();
    }

    public void setStudentName(String name) {
        sample.setName(name);
    }
    public String getStudentId() {
        return sample.getId();
    }
    public void setStudentId(String id) {
        sample.setId(id);
    }
    public String getStudentGrade() {
        return sample.getGrade();
    }
    public void setStudentGrade(String grade) {
        sample.setGrade(grade);
    }
    public void updatedetails() {
        view.displayStudentDetails(sample.getName(), sample.getId(),sample.getGrade());
    }
}
