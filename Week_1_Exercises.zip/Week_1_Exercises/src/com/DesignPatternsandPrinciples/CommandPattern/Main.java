package com.DesignPatternsandPrinciples.CommandPattern;

public class Main {
    public static void main(String[] args) {
        Light light = new Light();
        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);

        // Creating the invoker
        RemoteControl remote = new RemoteControl();

        //Using the invoker performing the actions.
        remote.setCommand(lightOn);
        remote.pressButton();
        remote.setCommand(lightOff);
        remote.pressButton();
    }
}
