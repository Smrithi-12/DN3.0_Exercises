package com.DesignPatternsandPrinciples.CommandPattern;

public interface Command {
    void execute();
}
