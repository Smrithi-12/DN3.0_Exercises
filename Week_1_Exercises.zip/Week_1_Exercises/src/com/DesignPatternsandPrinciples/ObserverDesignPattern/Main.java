package com.DesignPatternsandPrinciples.ObserverDesignPattern;
/*
 Observer design pattern is used to notify all other objects about any change that occurs
 */
public class Main {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        MobileApp mobileApp = new MobileApp();
        WebApp webApp = new WebApp();

        stockMarket.register(mobileApp);
        stockMarket.register(webApp);

        // Changing the stock price to notify observers
        stockMarket.setStockPrice(160);
        stockMarket.setStockPrice(175);
    }
}
