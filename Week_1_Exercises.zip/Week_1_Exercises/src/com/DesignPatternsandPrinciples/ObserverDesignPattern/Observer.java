package com.DesignPatternsandPrinciples.ObserverDesignPattern;

public interface Observer {
    void update(double stockPrice);
}
