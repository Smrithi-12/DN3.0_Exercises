package com.DesignPatternsandPrinciples.AdapterDesignPattern;

import java.util.List;
/*
   Testing whether the operations perform correctly (Tester class).
 */
public class Main {
    public static void main(String[] args) {
        Client client = new Client();
        List<PaymentProcessor> payees = client.getPayeeList();

        for (PaymentProcessor payee : payees) {
            System.out.println("Name: " + payee.getName());
            System.out.println("Payment: " + payee.getpay());
            System.out.println("Email: " + payee.getEmail());
            System.out.println("---------------");
        }
    }
}
