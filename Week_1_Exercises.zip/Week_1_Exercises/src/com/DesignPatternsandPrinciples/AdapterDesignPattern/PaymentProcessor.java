package com.DesignPatternsandPrinciples.AdapterDesignPattern;

public interface PaymentProcessor {
    public String getName();
    public String getpay();
    public String getEmail();
}
