package com.DesignPatternsandPrinciples.AdapterDesignPattern;
/*
    --> Adapts the PaytmPayment to the PaymentProcessor interface.
    --> This allows PaytmPayment to be used where PaymentProcessor is expected.
 */
public class PaytmAdapter implements PaymentProcessor {
    private PaytmPayment paytmPayment;

    public PaytmAdapter(PaytmPayment paytmPayment) {
        this.paytmPayment = paytmPayment;
    }

    @Override
    public String getName() {
        return this.paytmPayment.getFullName();
    }

    @Override
    public String getpay() {
        return this.paytmPayment.getPayment();
    }

    @Override
    public String getEmail() {
        return this.paytmPayment.getEmailAddress();
    }
}
