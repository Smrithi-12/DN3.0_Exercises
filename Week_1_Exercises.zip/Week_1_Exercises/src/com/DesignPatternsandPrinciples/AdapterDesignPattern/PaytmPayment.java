package com.DesignPatternsandPrinciples.AdapterDesignPattern;
/*
    This class represents the PaytmPayment with its own method names and properties.
 */
public class PaytmPayment {
        private String payment;
        private String fullName;
        private String emailAddress;

        public PaytmPayment(String payment, String fullName, String emailAddress) {
            this.payment = payment;
            this.fullName = fullName;
            this.emailAddress = emailAddress;
        }

        public String getPayment() {
            return payment;
        }

        public String getFullName() {
            return fullName;
        }

        public String getEmailAddress() {
            return emailAddress;
        }
}


