package com.DesignPatternsandPrinciples.AdapterDesignPattern;
public class GpayPayment implements PaymentProcessor {
    private String pay;
    private String name;
    private String email;
    public GpayPayment(String pay, String name, String email) {
        this.name = name;
        this.pay = pay;
        this.email = email;
    }
    @Override
    public String getpay() {
        return pay;
    }
    @Override
    public String getEmail() {
        return email;
    }
    @Override
    public String getName(){
        return name;
    }
}

