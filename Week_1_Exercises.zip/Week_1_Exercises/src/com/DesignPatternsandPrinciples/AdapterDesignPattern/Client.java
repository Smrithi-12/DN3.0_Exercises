package com.DesignPatternsandPrinciples.AdapterDesignPattern;

import java.util.ArrayList;
import java.util.List;
/*
 This client class Demonstrates how to use the GpayPayment and PaytmAdapter to handle different payment systems uniformly.
 */
public class Client {
    public List<PaymentProcessor> getPayeeList() {
        List<PaymentProcessor> payees = new ArrayList<>();

        GpayPayment gpay = new GpayPayment("1000", "abc", "abc@gmail.com");
        PaytmPayment paytm = new PaytmPayment("1500", "xyz", "xyz@gmail.com");
        PaytmAdapter paytmAdapter = new PaytmAdapter(paytm);

        payees.add(gpay);
        payees.add(paytmAdapter);
        return payees;
    }
}
