package com.DesignPatternsandPrinciples.StrategyDesigbPattern;

public class CreditCardPayment implements PaymentStrategy {
    private String card;
    private String name;
    public CreditCardPayment(String card,String name){
        this.card = card;
        this.name = name;
    }
    @Override
    public void pay(double amount){
        System.out.println("Processing credit card payment");
    }
}
