package com.DesignPatternsandPrinciples.StrategyDesigbPattern;

public interface PaymentStrategy {
    void pay(double amount);
}
