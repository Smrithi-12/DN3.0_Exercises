package com.DesignPatternsandPrinciples.StrategyDesigbPattern;
/*
   Creating 2 different context and such as credit card - payment and the Paypal payment
 */
public class Main {
    public static void main(String[] args) {
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-5432", "abc");
        PaymentStrategy paypalPayment = new PayPalPayment("1234567890");

        // Create context with CreditCardPayment strategy
        PaymentContext paymentContext = new PaymentContext(creditCardPayment);
        paymentContext.executePayment(200.00);

        // Change to PayPalPayment strategy
        paymentContext.setPaymentStrategy(paypalPayment);
        paymentContext.executePayment(0.00);
    }
}
