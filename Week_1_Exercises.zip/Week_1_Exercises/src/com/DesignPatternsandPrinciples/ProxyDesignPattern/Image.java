package com.DesignPatternsandPrinciples.ProxyDesignPattern;

public interface Image {
    void display();
}
