package com.DesignPatternsandPrinciples.ProxyDesignPattern;

public class Realmage implements Image{
    private String file;
    public Realmage(String file){
        this.file = file;
        loadImage();
    }
    private void loadImage(){
        System.out.println("Loading image " + file);
    }
    public void display(){
        System.out.println("Displaying image " + file);
    }
}
