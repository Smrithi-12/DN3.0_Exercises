package com.DesignPatternsandPrinciples.ProxyDesignPattern;
/*
    Proxy pattern is one where providing extra control on a specific object.
    --> Here this also includes the lazy initialization.
 */
public class Main {
    public static void main(String[] args){
        Image img1 = new ProxyImage("img1");
        // Here the image is loaded for the 1st time
        img1.display();
        // Here the image is not loaded and performs only displaying function because that is cached in the proxy
        img1.display();
    }
}
