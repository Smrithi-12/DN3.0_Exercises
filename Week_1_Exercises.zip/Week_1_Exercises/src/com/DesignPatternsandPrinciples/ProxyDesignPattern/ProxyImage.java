package com.DesignPatternsandPrinciples.ProxyDesignPattern;

public class ProxyImage implements Image{
    private Realmage realmage;
    private String file;

    public ProxyImage(String file){
        this.file = file;
    }
    @Override
    public void display(){
        if(realmage == null){
            realmage = new Realmage(file);
        }
        realmage.display();
    }
}
