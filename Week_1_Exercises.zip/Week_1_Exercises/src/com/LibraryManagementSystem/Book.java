package com.LibraryManagementSystem;

public class Book {
    private String Id;
    private String title;
    private String author;

    public Book(String id, String title, String author) {
        Id = id;
        this.title = title;
        this.author = author;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
    public String toString() {
        return "ID: " + Id + " Title: " + title + " Author: " + author;
    }
}
