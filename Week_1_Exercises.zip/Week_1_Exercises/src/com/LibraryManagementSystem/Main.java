package com.LibraryManagementSystem;

public class Main {
    public static void main(String[] args) {
        // Linear Search
        LinearSearch linearSearchLibrary = new LinearSearch();
        linearSearchLibrary.addBook(new Book("1", "The", "F"));
        linearSearchLibrary.addBook(new Book("2", "Moby Dick", "H"));
        linearSearchLibrary.addBook(new Book("3", "1984", "Geo"));
        linearSearchLibrary.addBook(new Book("4", "To Kill a Mockingbird", "Har"));

        System.out.println("Linear Search:");
        Book foundBook = linearSearchLibrary.linearSearchByTitle("1984");
        System.out.println(foundBook != null ? foundBook : "Book not found");

        // Binary Search
        BinarySearch binarySearchLibrary = new BinarySearch();
        binarySearchLibrary.addBook(new Book("1", "Great", "d"));
        binarySearchLibrary.addBook(new Book("2", "Moby", "Hle"));
        binarySearchLibrary.addBook(new Book("3", "1984", "ll"));
        binarySearchLibrary.addBook(new Book("4", "Kill", "fg"));

        binarySearchLibrary.sortBooksByTitle();

        System.out.println("\nBinary Search:");
        foundBook = binarySearchLibrary.binarySearchByTitle("1984");
        System.out.println(foundBook != null ? foundBook : "Book not found");
    }
}
