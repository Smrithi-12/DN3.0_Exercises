// SinglyLL.java
package com.TaskManagementSystem;

public class SinglyLL {
    private Node head;

    public SinglyLL() {
        this.head = null;
    }

    // Add task to the end of the list
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(newNode);
        }
    }

    // Search for a task by ID
    public Task searchTaskById(String taskId) {
        Node current = head;
        while (current != null) {
            if (current.getTask().getId().equals(taskId)) {
                return current.getTask();
            }
            current = current.getNext();
        }
        return null; // Task not found
    }

    // Traverse and print all tasks
    public void printAllTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.getTask());
            current = current.getNext();
        }
    }

    // Delete a task by ID
    public void deleteTaskById(String taskId) {
        if (head == null) {
            System.out.println("The list is empty.");
            return;
        }

        // Check if the head node is the one to delete
        if (head.getTask().getId().equals(taskId)) {
            head = head.getNext();
            return;
        }

        Node current = head;
        while (current.getNext() != null && !current.getNext().getTask().getId().equals(taskId)) {
            current = current.getNext();
        }

        if (current.getNext() == null) {
            System.out.println("Task not found.");
            return;
        }

        // Remove the node with the matching taskId
        current.setNext(current.getNext().getNext());
    }
}
