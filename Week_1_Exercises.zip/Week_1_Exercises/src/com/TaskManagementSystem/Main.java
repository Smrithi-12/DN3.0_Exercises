package com.TaskManagementSystem;

public class Main {
    public static void main(String[] args) {
        SinglyLL taskList = new SinglyLL();
        // Add
        taskList.addTask(new Task("1", "abc", "Rejected"));
        taskList.addTask(new Task("2", "bca", "Pending"));
        taskList.addTask(new Task("3", "xyz", "Completed"));

        // Print
        System.out.println("All Tasks:");
        taskList.printAllTasks();

        // Search
        System.out.println("Searching");
        Task task = taskList.searchTaskById("2");
        if (task != null) {
            System.out.println(task);
        } else {
            System.out.println("Task not found.");
        }

        // Delete
        System.out.println("Deleting");
        taskList.deleteTaskById("1");

        // Print
        System.out.println("Tasks after deletion:");
        taskList.printAllTasks();
    }
}
