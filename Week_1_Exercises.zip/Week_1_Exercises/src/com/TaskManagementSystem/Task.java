package com.TaskManagementSystem;

public class Task {
    private String Id;
    private String Name;
    private String status;

    public Task(String id, String name, String status) {
        Id = id;
        Name = name;
        this.status = status;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    @Override
    public String toString() {
        return "ID: " + Id + ", Name: " + Name + ", Status: " + status;
    }
}
