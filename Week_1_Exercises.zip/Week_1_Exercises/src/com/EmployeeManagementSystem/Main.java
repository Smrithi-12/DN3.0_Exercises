package com.EmployeeManagementSystem;

public class Main {
    public static void main(String[] args) {
        Controller manager = new Controller(5);

        // Add
        manager.addEmployee(new Employee("1", "abc", "Developer", 75000));
        manager.addEmployee(new Employee("2", "cde", "Manager", 85000));
        manager.addEmployee(new Employee("3", "fgh", "Analyst", 65000));

        // Print
        System.out.println("All Employees:");
        manager.printAllEmployees();

        // Search
        System.out.println("\nSearching");
        Employee employee = manager.searchEmployeeById("2");
        if (employee != null) {
            System.out.println(employee);
        } else {
            System.out.println("Employee not found.");
        }

        // Delete
        System.out.println("\nDeleting");
        manager.deleteEmployeeById("1");

        // Print after deletion
        System.out.println("\nAll Employees after deletion:");
        manager.printAllEmployees();
    }
}
