package com.EmployeeManagementSystem;

public class Controller {
    private Employee[] employees;
    private int size;
    public Controller(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }
    //ADD
    public void addEmployee(Employee employee) {
        if (size < employees.length) {
            employees[size++] = employee;
        } else {
            System.out.println("Array is full");
        }
    }
    //SEARCH
    public Employee searchEmployeeById(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    // TRAVERSE
    public void printAllEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // DELETE
    public void deleteEmployeeById(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getId().equals(employeeId)) {
                // Shift elements to the left
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[size - 1] = null;
                size--;
                return;
            }
        }
        System.out.println("Employee not found.");
    }
}
