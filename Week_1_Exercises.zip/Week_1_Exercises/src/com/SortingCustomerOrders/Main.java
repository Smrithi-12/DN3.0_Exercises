package com.SortingCustomerOrders;

public class Main {
    public static void main(String[] args) {
        Order[] orders = {
                new Order("1", "abc", 120),
                new Order("2", "xyz", 75.3),
                new Order("3", "ash", 20),
                new Order("4", "ush", 4),
                new Order("5", "Eve", 95)
        };
        System.out.println("Bubble Sort:");
        BubbleSort.sortOrdersByPrice(orders);
        for (Order order : orders) {
            System.out.println(order.getId() +" "+ order.getName() +" " +  order.getPrice());
        }
        orders = new Order[] {
                new Order("1", "abc", 120),
                new Order("2", "xyz", 75.3),
                new Order("3", "ash", 20),
                new Order("4", "ush", 4),
                new Order("5", "Eve", 95)
        };
        System.out.println("\nQuick Sort:");
        QuickSort.sortOrdersByPrice(orders, 0, orders.length - 1);
        for (Order order : orders) {
            System.out.println(order.getId() +" "+ order.getName()  +" "+ order.getPrice());
        }
    }
}
