package com.FinancialForecasting;

import java.util.*;
public class FinancialForecasting {
    private Map<Integer, Double> Map;

    public FinancialForecasting() {
        this.Map = new HashMap<>();
    }
    public double predictFutureValue(double presentValue, double growthRate, int years) {
        if (years == 0) {
            return presentValue;
        }

        if (Map.containsKey(years)) {
            return Map.get(years);
        }

        double futureValue = (1 + growthRate) * predictFutureValue(presentValue, growthRate, years - 1);
        Map.put(years, futureValue);
        return futureValue;
    }
    // HardCoded the present value, growthrate ana years for convinience
    public static void main(String[] args) {
        FinancialForecasting forecasting = new FinancialForecasting();
        double presentValue = 1000.0;
        double growthRate = 0.05;
        int years = 10;

        double futureValue = forecasting.predictFutureValue(presentValue, growthRate, years);
        System.out.println("Future Value after " + years + " years: " + futureValue);
    }
}
