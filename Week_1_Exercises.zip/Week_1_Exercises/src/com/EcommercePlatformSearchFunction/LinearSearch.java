package com.EcommercePlatformSearchFunction;

public class LinearSearch {
    public static Products searchByProductId(Products[] products, String productId) {
        for (Products product : products) {
            if (product.getProductId().equals(productId)) {
                return product;
            }
        }
        return null;
    }
}
