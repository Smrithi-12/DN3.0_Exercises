package com.EcommercePlatformSearchFunction;
import java.util.*;

public class Main {
        public static void main(String[] args) {
            Products[] products = {
                    new Products("1", "abc", "abc"),
                    new Products("2", "bca", "abc"),
                    new Products("3", "abcd", "abc"),
                    new Products("4", "pqrs", "abc"),
                    new Products("5", "zxc", "abc"),
                    new Products("6", "wer", "abc"),
                    new Products("7", "dfg", "abc"),
                    new Products("8", "rty", "abc"),
                    new Products("9", "sdf", "abc"),
                    new Products("10", "awer", "abc")
            };
            Arrays.sort(products, Comparator.comparing(Products::getProductId));

            String searchIdLinear = "11";
            Products resultLinear = LinearSearch.searchByProductId(products, searchIdLinear);
            if (resultLinear != null) {
                System.out.println("Linear Search Result:");
                System.out.println("Product ID: " + resultLinear.getProductId());
                System.out.println("Product Name: " + resultLinear.getProductName());
                System.out.println("Category: " + resultLinear.getCategory());
            } else {
                System.out.println("Linear - Product not found");
            }
            System.out.println("---------------------------");
            String searchIdBinary = "4";
            Products resultBinary = BinarySearch.searchByProductId(products, searchIdBinary);
            if (resultBinary != null) {
                System.out.println("Product ID: " + resultBinary.getProductId());
                System.out.println("Product Name: " + resultBinary.getProductName());
                System.out.println("Category: " + resultBinary.getCategory());
            } else {
                System.out.println("Binary - Product not found");
            }
        }
    }


