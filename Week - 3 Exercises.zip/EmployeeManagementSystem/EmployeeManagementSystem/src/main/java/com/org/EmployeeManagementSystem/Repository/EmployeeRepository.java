package com.org.EmployeeManagementSystem.Repository;
// Exercise 3

import com.org.EmployeeManagementSystem.Entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByDepartmentName(String departmentName);
    List<Employee> findByEmailContaining(String emailFragment);
    List<Employee> findByNameStartingWith(String prefix);
    List<Employee> findByNameEndingWith(String suffix);

    //Exercise 5
//    Custom query method using @Query
//    @Query("SELECT e FROM Employee e WHERE e.department.name = :departmentName")
//    List<Employee> findEmployeesByDepartmentName(@Param("departmentName") String departmentName);
//
//    // Custom SQL query to find employees by name pattern
//    @Query(value = "SELECT * FROM Employee e WHERE e.name LIKE %:pattern%", nativeQuery = true)
//    List<Employee> findEmployeesByNamePattern(@Param("pattern") String pattern);

    //Exercise 6
    // Paginated search
//    Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);

    // Exercise 8
//    @Query("SELECT e FROM Employee e")
//    List<EmployeeProjectionWithValue> findAllEmployeeProjectionsWithValue();

}
