package com.org.EmployeeManagementSystem.projection;

public interface EmployeeProjection {
    String getName();
    String getEmail();
}
