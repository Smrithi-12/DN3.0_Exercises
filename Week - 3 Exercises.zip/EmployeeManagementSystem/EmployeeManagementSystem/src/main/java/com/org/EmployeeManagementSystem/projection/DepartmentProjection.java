package com.org.EmployeeManagementSystem.projection;

public class DepartmentProjection {
    private final String name;
    public DepartmentProjection(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
}
