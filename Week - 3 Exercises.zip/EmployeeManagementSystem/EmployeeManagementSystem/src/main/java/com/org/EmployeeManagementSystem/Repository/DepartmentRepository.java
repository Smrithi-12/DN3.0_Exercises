package com.org.EmployeeManagementSystem.Repository;

// Exercise 3
import com.org.EmployeeManagementSystem.Entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    Department findByName(String name);
}

    //Exercise 8
//    @Query("SELECT new com.yourcompany.employeemanagementsystem.projection.DepartmentProjectionDTO(d.name) FROM Department d")
//    List<DepartmentProjectionDTO> findAllDepartmentProjections();

//    @Query("SELECT d FROM Department d")
//    List<DepartmentProjection> findAllDepartmentProjections();
