package com.library.aspect;
// Task - 3
public class LoggingAspect {

}
