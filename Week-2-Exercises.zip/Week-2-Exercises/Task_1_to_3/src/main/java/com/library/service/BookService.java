package com.library.service;

import com.library.repository.BookRepository;

public class BookService {
    private BookRepository bookRepository;
    public void setBookRepository(BookRepository bookRepository) { //--> Task-2 Implementing Setter method
        this.bookRepository = bookRepository;
    }
    public void print() {
        bookRepository.print();
    }
}
