package com.library.repository;

public class BookRepository {
    public void print() {
        System.out.println("This print method is called from bookService -> printing from bookRepository");
    }
}
