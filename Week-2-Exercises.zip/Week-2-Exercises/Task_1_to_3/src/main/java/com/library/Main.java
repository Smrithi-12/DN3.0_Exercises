package com.library;
/*
    Implementing both task 1 and task 2
    1. Configured a basic spring application
    2. Implemented dependency injection
    3. Implemented Logging with Spring AOP
 */
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.library.service.BookService;

public class Main {
    public static void main(String[] args) {
        System.out.println("Starting application");
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        System.out.println("Spring context loaded");
        BookService bookService = (BookService) context.getBean("bookService");
        System.out.println("BookService bean retrieved");
        bookService.print();
    }
}
