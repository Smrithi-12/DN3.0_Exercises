package org.library.task5.task7;
import org.library.task5.task7.Service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
           // Testing task - 5
//        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
//        BookService bookService = (BookService) context.getBean("bookService"); // Task - 5
//        bookService.print(); // Task - 5

        // Testing task - 7
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        BookService bookService = (BookService) context.getBean("bookService");
        bookService.print(); // Task - 7


    }
}