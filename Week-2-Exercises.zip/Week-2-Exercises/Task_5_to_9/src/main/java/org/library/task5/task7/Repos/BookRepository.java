package org.library.task5.task7.Repos;

public class BookRepository {
    public void print() {
        System.out.println("This is bookRepository -> called from BookService");
    }
}
