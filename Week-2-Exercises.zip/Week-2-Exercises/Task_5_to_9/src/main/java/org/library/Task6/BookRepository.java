package org.library.Task6;

import org.springframework.stereotype.Repository;
@Repository
public class BookRepository {
    public void print() {
        System.out.println("BookRepository");
    }
}


