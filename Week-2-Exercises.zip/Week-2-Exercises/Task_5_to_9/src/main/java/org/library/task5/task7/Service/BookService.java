package org.library.task5.task7.Service;
import org.library.task5.task7.Repos.BookRepository;
public class BookService {
    private BookRepository bookRepository;

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }
    public void print(){
        System.out.println("This is BookService");
        bookRepository.print();
    }
}
