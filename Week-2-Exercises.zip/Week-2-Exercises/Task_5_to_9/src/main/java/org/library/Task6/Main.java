package org.library.Task6;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        System.out.println("Starting application");
        ApplicationContext context = new AnnotationConfigApplicationContext("org.library"); // Load application context with annotation
        System.out.println("Spring context loaded");
        BookService bookService = context.getBean(BookService.class);
        System.out.println("BookService bean retrieved");
        bookService.print();
    }
}

