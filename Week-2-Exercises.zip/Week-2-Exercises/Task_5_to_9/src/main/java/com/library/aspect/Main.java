package com.library.aspect;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.library.task5.task7.Service.BookService;
    // Task - 8
public class Main {
    public static void main(String[] args) {
        System.out.println("Starting application");
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        System.out.println("Spring context loaded");
        BookService bookService = (BookService) context.getBean("bookService");
        System.out.println("BookService bean retrieved");
        bookService.print();
    }
}
